<?php
// list-tasks-page.php

// Определите имя таблицы для задач и наказаний
$table_name = $wpdb->prefix . 'items_show';

// Запрос к базе данных для выборки данных из таблицы
$query = "SELECT * FROM $table_name";
$items = $wpdb->get_results($query);

?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <h1>Список задач и наказаний</h1>

        <?php
        if ($items) {
            echo '<table>';
            echo '<tr><th>ID</th><th>Тип</th><th>Название</th><th>Описание</th><th>Сложность</th><th>Отправитель</th><th>Дата создания</th></tr>';
            foreach ($items as $item) {
                echo '<tr>';
                echo '<td>' . esc_html($item->id) . '</td>';
                echo '<td>' . esc_html($item->task_type) . '</td>';
                echo '<td>' . esc_html($item->task_name) . '</td>';
                echo '<td>' . esc_html($item->task_description) . '</td>';
                echo '<td>' . esc_html($item->task_difficulty) . '</td>';
                echo '<td>' . esc_html($item->task_sender) . '</td>';
                echo '<td>' . esc_html($item->created_at) . '</td>';
                echo '</tr>';
            }
            echo '</table>';
        } else {
            echo 'Задач и наказаний пока нет.';
        }
        ?>

    </main>
</div>

