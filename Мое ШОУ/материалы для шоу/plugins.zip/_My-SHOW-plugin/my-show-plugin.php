<!-- Главный файл плагина, в котором будет код для добавления страниц меню и общей конфигурации. -->

<?php
/**
 * Plugin Name: My Show Plugin
 * Description: Этот плагин разработан для проекта "Мое ШОУ" что проходит на Youtube канале Anato Fabian
 * Author: Анатолий Шипилов (Anato Fabian)
 * Version:           2023.1.4
 * Author:            Анатолий Шипилов (Anato Fabian)
 * Author URI:        https://www.youtube.com/@AnatoFabian
 * License:           GPLv2 (or later)
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * 
 */

// Подключение файла с кодом для добавления страниц меню
require_once plugin_dir_path(__FILE__) . 'menu-page.php';

// Подключение файла с кодом для страницы "Добавление задания"
require_once plugin_dir_path(__FILE__) . 'add-task-page.php';

// Подключение файла с кодом для страницы "Список заданий"
// require_once plugin_dir_path(__FILE__) . 'list-tasks-page.php';

// Подключение файла с кодом для страницы "Добавление участника"
require_once plugin_dir_path(__FILE__) . 'add-participant-page.php';

// Подключение файла с кодом для страницы "Список участников"
require_once plugin_dir_path(__FILE__) . 'list-participants-page.php';

// Подключение файла с кодом для страницы "Настройка шоу"
require_once plugin_dir_path(__FILE__) . 'show-settings-page.php';

// Подключение файла с кодом для страницы "Запуск трансляции"
require_once plugin_dir_path(__FILE__) . 'start-broadcast-page.php';

// Подключение файла с кодом для страницы "Запуск мониторов"
require_once plugin_dir_path(__FILE__) . 'start-monitors-page.php';
// Подключение файла с кодом для страницы "Настройка панели"
require_once plugin_dir_path(__FILE__) . 'show-settings-page.php';

// Дополнительные функции и настройки вашего плагина можно добавить ниже

function my_show_add_menu() {
    add_menu_page('Мои Задачи и Наказания', 'Задачи и Наказания', 'manage_options', 'list-tasks-page', 'list_tasks_page');
}

function list_tasks_page() {
    include 'list-tasks-page.php';
}
add_action('admin_menu', 'my_show_add_menu');

// Добавьте функцию обработки формы в вашем плагине
function save_menu_settings() {
    if (isset($_POST['save_settings'])) {
        update_option('show_edit', isset($_POST['show_edit']));
        update_option('show_upload', isset($_POST['show_upload']));
        update_option('show_comments', isset($_POST['show_comments']));
    }
}

// Добавьте хук для обработки формы
add_action('admin_init', 'save_menu_settings');
