function my_show_settings_page() {
    ?>
    <div class="wrap">
        <h2>Настройки ШОУ</h2>
        <form method="post" action="">
            <!-- Шаг 1: Форма для создания команды -->
            <h3>ШАГ 1: Создание команды</h3>
            <input type="text" name="team_name" placeholder="Название команды" required>
            <input type="text" name="captain_name" placeholder="Имя капитана" required>
            <input type="file" name="avatar" accept="image/*" required>
            <input type="color" name="team_color" required>
            <input type="color" name="team_color2" required>
            <button type="submit" name="create_team">Создать команду</button>
            
            <!-- Шаг 2: Форма для выбора банка -->
            <h3>ШАГ 2: Выбор банка</h3>
            <input type="range" name="bank" min="1500" max="25000" step="100" required>
            <button type="submit" name="select_bank">Выбрать банк</button>
        </form>

        <form method="post" action="">
            <h2>Настройки пунктов меню</h2>
            <label for="show_edit">Показать edit.php</label>
            <input type="checkbox" name="show_edit" id="show_edit" <?php echo get_option('show_edit') ? 'checked' : ''; ?>><br>

            <label for="show_upload">Показать upload.php</label>
            <input type="checkbox" name="show_upload" id="show_upload" <?php echo get_option('show_upload') ? 'checked' : ''; ?>><br>

            <label for="show_comments">Показать edit-comments.php</label>
            <input type="checkbox" name="show_comments" id="show_comments" <?php echo get_option('show_comments') ? 'checked' : ''; ?>><br>

            <input type="submit" name="save_settings" value="Сохранить настройки">
        </form>
    </div>
    <?php
}
