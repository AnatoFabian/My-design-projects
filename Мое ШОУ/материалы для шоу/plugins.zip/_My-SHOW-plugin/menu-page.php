<!-- Файл с кодом для отображения страницы "Мое ШОУ" и создания меню. -->
<?php
/**
 * Plugin Name: My Show Plugin
 * Description: Этот плагин разработан для проекта "Мое ШОУ" что проходит на Youtube канале Anato Fabian
 * Author: Анатолий Шипилов (Anato Fabian)
 * Version:           2023.1.4
 * Author:            Анатолий Шипилов (Anato Fabian)
 * Author URI:        https://www.youtube.com/@AnatoFabian
 * License:           GPLv2 (or later)
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * 
 */
// Добавляем пункты в левое меню
function add_my_show_menu_items() {
    add_menu_page('Мое ШОУ', 'Мое ШОУ', 'manage_options', 'my-show-menu', 'my_show_menu_page', 'dashicons-video-alt');
    add_submenu_page('my-show-menu', 'Добавление задания', 'Добавление задания', 'manage_options', 'add-task', 'add_task_page');
    add_submenu_page('my-show-menu', 'Список заданий', 'Список заданий', 'manage_options', 'list-tasks', 'list_tasks_page');

    add_submenu_page('my-show-menu', 'Добавить участника', 'Добавить участника', 'manage_options', 'add-participant', 'add_participant_page');
    add_submenu_page('my-show-menu', 'Список участников', 'Список участников', 'manage_options', 'list-participants', 'list_participants_page');

    add_submenu_page('my-show-menu', 'Настройки Шоу', 'Настройки Шоу', 'manage_options', 'show-settings', 'show_settings_page');
    function my_show_menu_page() {
        // Здесь вы можете определить содержимое страницы
        echo '<div class="wrap">';
        echo '<h2>Настройки ШОУ</h2>';
        // Добавьте ваш HTML-код для страницы настроек здесь
        echo '</div>';
    }
    
    function my_menu() {
        add_menu_page('ШОУ Настройки', 'Настройки ШОУ', 'manage_options', 'my-show-settings', 'my_show_menu_page');
    }
    
    add_action('admin_menu', 'my_menu');
    
    add_submenu_page('my-show-menu', 'Запуск трансляции', 'Запуск трансляции', 'manage_options', 'start-broadcast', 'start_broadcast_page');
    add_submenu_page('my-show-menu', 'Запуск мониторов', 'Запуск мониторов', 'manage_options', 'start-monitors', 'start_monitors_page');
}
add_action('admin_menu', 'add_my_show_menu_items');
