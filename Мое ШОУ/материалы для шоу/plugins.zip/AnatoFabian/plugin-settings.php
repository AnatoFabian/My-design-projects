<?php
// Функция для получения класса стиля на основе сложности
function get_difficulty_style($difficulty) {
    
}

function list_tasks_page() {
    
    ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

            <h1>Список задач и наказаний</h1>

            

        </main>
    </div>
    
    <?php
}
?>
