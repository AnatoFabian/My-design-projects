<?php
/*
Plugin Name: Anato Fabian 
Description: Плагин разработан для управления шоу, которое выходит на канале Anato Fabian.
Version: 2023.2.1
Author: Анатолий Шипилов (Anato Fabian)
Author URI: https://www.youtube.com/@AnatoFabian
License: GPLv2 (or later)
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// Подключаем файлы
function load_plugin_css() {
    wp_register_style('anato-fabian-plugin-css', plugins_url('/plugin.css', __FILE__));
    wp_enqueue_style('anato-fabian-plugin-css');
}
// Подключите WordPress
require_once(ABSPATH . 'wp-admin/includes/plugin.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');


include(plugin_dir_path(__FILE__) . 'settings/plugin-settings.php');
include(plugin_dir_path(__FILE__) . 'index-plugin.php');
include(plugin_dir_path(__FILE__) . 'add-participant-page.php');
include(plugin_dir_path(__FILE__) . 'load-players.php');
include(plugin_dir_path(__FILE__) . 'list-tasks-page.php');
include(plugin_dir_path(__FILE__) . 'add-task-page.php');





function my_custom_plugin_menu() {
    add_menu_page(
        'Мое Шоу',
        'Мое Шоу',
        'manage_options',
        'my-show-page',
        'my_show_page_content',
        'dashicons-youtube'
    );

    
    add_menu_page(
        'Добавление участника',
        'Добавить участника',
        'manage_options',
        'add-participant-page',
        'add_participant_page',
        'dashicons-admin-users' // Иконка пользователя
    );

    add_menu_page(
        'Список участников',
        'Все Участники ШОУ',
        'manage_options',
        'load-players-page',
        'load_players_page',
        'dashicons-buddicons-buddypress-logo' // Иконка пользователя
    );

    add_menu_page(
        'Добавить задание',
        'Добавить Задание',
        'manage_options',
        'add-task-page', 
        'add_task_page',
        'dashicons-plus' // Иконка пользователя
    );
 
    add_menu_page(
        'Список задач и наказаний',
        'Список задач и наказаний',
        'manage_options',
        'list-tasks-page',
        'list_tasks_page',
        'dashicons-list-view' // Иконка списка
    );
    add_menu_page(
        'Настройки',
        'Настройки приложения',
        'manage_options',
        'my-settings-page',
        'my_settings_page_content',
        'dashicons-admin-settings'
    );

    add_menu_page(
        'Запуск ',
        'Трансляции',
        'manage_options',
        'start-stream-page',
        'start_stream_page_content',
        'dashicons-welcome-view-site'
    );
   


    
}

add_action('admin_menu', 'my_custom_plugin_menu');

function start_stream_page_content() {
    // Содержание страницы "Запуск трансляции"
require_once plugin_dir_path(__FILE__) . 'show-start.php';

}

function add_participant_page_content() {
    // Содержание страницы "Добавить участника"
}
function participants_list_page_content() {
    // Содержание страницы "Список участников"
    require_once plugin_dir_path(__FILE__) . 'add-participant-page.php';
}
function add_task_page_content() {
    
    // Содержание страницы "Добавить задание"
}
function tasks_list_page_content() {
    // Содержание страницы "Список заданий"
}
// function tasks_list_page_content() {
    // Содержание страницы "Список заданий"


// И так далее для остальных страниц
