<h2>Начать трансляцию </h2>
<div id="welcome-panel" class="welcome-panel">
	<div class="welcome-panel-column-container">
		<div class="welcome-panel-column">
        <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Настройка выпуска</h3>
                <a href="/wp-admin/admin.php?page=show-settings-page" class="page-title-action button" role="button" aria-expanded="false">Натроить новый выпуск</a>
			</div>
		</div>
		<div class="welcome-panel-column">
            <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Панель ведущего</h3>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Панель ведущего</a>
			</div>
		</div>
        <div class="welcome-panel-column">
            <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Панель игроков</h3>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Экран игрока 1</a>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Экран игрока 2</a>
			</div>
		</div>
        <div class="welcome-panel-column">
            <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Монитор в студии</h3>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Заупуск Монитора в студии</a>
			</div>
		</div>
        <div class="welcome-panel-column">
            <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Настройка монитора трансляции</h3>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Настройка трансляции</a>
			</div>
		</div>
        <div class="welcome-panel-column">
            <a href="#" target="_blank" rel="noopener noreferrer">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
			</svg>
            </a>
			<div class="welcome-panel-column-content">
				<h3>Монитор для трансляции</h3>
                <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action button" role="button" aria-expanded="false">Заупуск монитора трансляции</a>
			</div>
		</div>
	</div>
	</div>
		</div>