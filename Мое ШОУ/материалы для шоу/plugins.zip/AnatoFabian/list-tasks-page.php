<?php
// Функция для получения класса стиля на основе сложности
function get_difficulty_style($difficulty) {
    switch ($difficulty) {
        case '1':
            return 'difficulty difficulty-1'; // Класс стиля для сложности 1
        case '2':
            return ' difficulty-2'; // Класс стиля для сложности 2
        case '3':
            return 'difficulty difficulty-3'; // Класс стиля для сложности 3
        case '4':
            return 'difficulty difficulty-4'; // Класс стиля для сложности 4
        default:
            return ''; // По умолчанию, нет стиля
    }
}

function list_tasks_page() {
    if (!current_user_can('manage_options')) {
        wp_die('У вас нет прав для просмотра этой страницы.');
    }
    // Определите имя таблицы для задач и наказаний
    global $wpdb;

    if ($wpdb) {
        $table_name = $wpdb->prefix . 'items_show';

        // Запрос к базе данных для выборки данных из таблицы

        $query = "SELECT * FROM $table_name";
        $items = $wpdb->get_results($query);
    } else {
        echo 'Ошибка: объект $wpdb не инициализирован.';
    }
    ?>

    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">

            <h1>Список задач и наказаний</h1>

            <?php
            if ($items) {
                echo '<table>';
                echo '<tr><th>ID</th><th>Тип</th><th style="width: 100px;">Название</th><th>Описание</th><th>Сложность</th><th>Автор задания</th><th>Соц. Сеть</th><th style="width: 35px;">Дата создания</th></tr>';
                echo '<td class="task_social_network">';
                    // Используйте изображение в зависимости от значения $item->task_social_network
                    if ($item->task_social_network === 'Facebook') {
                        echo '<img src="путь_к_изображению_facebook.png" alt="Facebook">';
                    } elseif ($item->task_social_network === 'Instagram') {
                        echo '<img src="путь_к_изображению_instagram.png" alt="Instagram">';
                    } elseif ($item->task_social_network === 'Twitter') {
                        echo '<img src="путь_к_изображению_twitter.png" alt="Twitter">';
                    } elseif ($item->task_social_network === 'VKontakte') {
                        echo '<img src="путь_к_изображению_vkontakte.png" alt="VKontakte">';
                    } elseif ($item->task_social_network === 'Tik-Tok') {
                        echo '<img src="путь_к_изображению_tiktok.png" alt="Tik-Tok">';
                    } elseif ($item->task_social_network === 'YouTube') {
                        echo '<img src="путь_к_изображению_youtube.png" alt="YouTube">';
                    } else {
                        // Если значение не совпадает ни с одной из социальных сетей, отобразите текст
                        echo esc_html($item->task_social_network);
                    }
                    echo '</td>';

                foreach ($items as $item) {
                    $date_created = date('d/F/Y', strtotime($item->created_at));

                    // Получите класс стиля для сложности
                    $difficulty_style = get_difficulty_style($item->task_difficulty);

                    // Определите класс строки в зависимости от типа задачи
                    // $row_class = ($item->task_type === 'punishment') ? 'punishment' : 'task';

                    echo '<tr class="liner' . esc_attr($row_class) . '">';
                    echo '<td class="task_id">' . esc_html($item->id) . '</td>';
                    echo '<td  class="task_type">' . ($item->task_type === 'punishment' ? '<span class="task">Наказание</span>' : '<span class="punishment">Задание') . '</td>';
                    echo '<td class="task_name">' . esc_html($item->task_name) . '</td>';
                    echo '<td class="task_description">' . esc_html($item->task_description) . '</td>';
                    echo '<td class="' . esc_attr($difficulty_style) . '">' . esc_html($item->task_difficulty) . '</td>';
                    echo '<td class="task_sender">' . esc_html($item->task_sender) . '</td>';
                    echo '<td class="task_social_network">' . esc_html($item->task_social_network) . '</td>';
                    echo '<td class="task_date">' . esc_html($date_created) . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo 'Задач и наказаний пока нет.';
            }
            ?>

        </main>
    </div>
    <style>
        .liner{
            
        }
        .task_id {
            width: 2%;
            border-left: 1px #f3f3f3 solid;
            text-align: center;
            font-weight: bold;
            border: 1px gray solid;
        }

        .task_type {
            width: 10%;
            border-left: 1px #f3f3f3 solid;
            padding: 0 5px;
            border: 1px gray solid;
        }

        .task_description {
            padding: 0 10px;
            width: 45%;
            border-left: 1px #f3f3f3 solid;
            border: 1px gray solid;
        }

        .task_difficulty {
            width: 2%;
            border-left: 1px #f3f3f3 solid;
            text-align: center;
            border: 1px gray solid;
        }

        .task_sender {
            width: 15%;
            border-left: 1px #f3f3f3 solid;
            text-align: center;
            font-weight: bold;
            border: 1px gray solid;
        }
        .task_social_network {
            width: 10%;
            border-left: 1px #f3f3f3 solid;
            text-align: center;
            font-weight: bold;
            border: 1px gray solid;
        }
        .task_name {
            text-align: center;
            width: 10%;
            font-weight: 700;
            border-left: 1px #f3f3f3 solid;
            border: 1px gray solid;
        }

        .task_date{
            width: 35px; 
            text-align: center;
            font-weight: 700;
            border: 1px gray solid;
        }
        .task {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            border: 2px solid #795548;
            background-color: #795548;
            color: #fff;
            font-weight: 700;
            text-align: center;
            border-width: 0 35px;
        }
        .punishment {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            border: 2px solid #FF5722;
            background-color: #FF5722;
            color: #fff;
            font-weight: 700;
            border-width: 0 43px;
        }

        .difficulty {
            /* background-color: #00796B; */
            text-align: center;
            font-weight: bold;
            color: #fff;
            width: 5%;
            height: 15spx;
            border-width: 0 43px;

        }


        .difficulty-1 {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            color: #000;
            font-weight: 700;
            text-align: center;
            border-width: 0 35px;
            border: 2px solid #00796B;
            background-color: #00796B;
        }
        .difficulty-2 {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            color: #000;
            font-weight: 700;
            text-align: center;
            border-width: 0 35px;
            border: 2px solid #FFA000;
            background-color: #FFA000;
        }

        .difficulty-3 {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            color: #000;
            font-weight: 700;
            text-align: center;
            border-width: 0 35px;
            border: 2px solid #FF5722;
            background-color: #FF5722;
        }

        .difficulty-4 {
            text-align: center;
            font-size: 15px;
            padding: 5px 6px;
            color: #000;
            font-weight: 700;
            text-align: center;
            border-width: 0 35px;
            border: 2px solid #D32F2F;
            background-color: #D32F2F;
        }

        .facebook-icon {
            background-image: url('путь-к-вашей-иконке/facebook-icon.png');
            width: 20px;
            height: 20px;
            display: inline-block;
            background-size: cover;
        }

        .instagram-icon {
            background-image: url('путь-к-вашей-иконке/instagram-icon.png');
            width: 20px;
            height: 20px;
            display: inline-block;
            background-size: cover;
        }
    </style>
    <?php
}
?>
