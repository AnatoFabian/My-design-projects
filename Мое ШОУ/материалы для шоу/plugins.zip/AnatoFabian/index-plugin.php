<?php

function my_show_page_content() {
    echo '<div class="wrap">';
    echo '<h2>Мое Шоу</h2>';
    
    echo '
    
    <div id="welcome-panel" class="welcome-panel">
			<div class="welcome-show-panel">
            
	<div class="welcome-show-panel  welcome-panel-header">
		<h2>Панель управления "Мое ШОУ" </h2>
		<p><a href="https://www.youtube.com/@AnatoFabian">Мой канал на Youtube</a></p>
	</div>
	<div class="welcome-panel-column-container">
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
				<path fill-rule="evenodd" clip-rule="evenodd" d="M32.0668 17.0854L28.8221 13.9454L18.2008 24.671L16.8983 29.0827L21.4257 27.8309L32.0668 17.0854ZM16 32.75H24V31.25H16V32.75Z" fill="white"></path>
			</svg>
			<div class="welcome-panel-column-content">
				<h3>Настрайвайте ваше шой максимально удобно для вас</h3>
				<p>Вы можете настраивать внешний вид вашего шоу и трансляций так как вам удобно и быстро.</p>
				<a href="/wp-admin/admin.php?page=my-settings-page">Перейти в настройки</a>
			</div>
		</div>
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
				<path fill-rule="evenodd" clip-rule="evenodd" d="M18 16h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H18a2 2 0 0 1-2-2V18a2 2 0 0 1 2-2zm12 1.5H18a.5.5 0 0 0-.5.5v3h13v-3a.5.5 0 0 0-.5-.5zm.5 5H22v8h8a.5.5 0 0 0 .5-.5v-7.5zm-10 0h-3V30a.5.5 0 0 0 .5.5h2.5v-8z" fill="#fff"></path>
			</svg>
			<div class="welcome-panel-column-content">
							<h3>Задания и наказания</h3>
				<p>Добавляйте задания и наказания для участников вашего шоу. Так же просматривайте и редактируйте задания и наказания.</p>
				<a href="/wp-admin/admin.php?page=add-task-page">Добавить задания и наказание</a> 
				</br>
				<a href="/wp-admin/admin.php?page=list-tasks-page">Просмотр заданий и наказаний</a>
						</div>
		</div>
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#fe7c0c"></rect>
				<path fill-rule="evenodd" clip-rule="evenodd" d="M31 24a7 7 0 0 1-7 7V17a7 7 0 0 1 7 7zm-7-8a8 8 0 1 1 0 16 8 8 0 0 1 0-16z" fill="#fff"></path>
			</svg>
			<div class="welcome-panel-column-content">
							<h3>Управляйте участниками вашего шоу</h3>
				<p>Добавляйте участников быстро, а так же просматривайте и выставляйте им рейтинг.</p>
				<a href="/wp-admin/admin.php?page=add-participant-page">Изменить стили</a>
				</br>
				<a href="/wp-admin/admin.php?page=load-players-page">Изменить стили</a>
						</div>
		</div>
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#000000"></rect>
			</svg>
			<div class="welcome-panel-column-content">
							<h3>Запустить панель ведушего</h3>
							</br>
				<a href="/wp-admin/admin.php?page=show-admin-page" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">Панель ведушего</a>
						</div>
		</div>
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#000000"></rect>
			</svg>
			<div class="welcome-panel-column-content">
							<h3>Игрок 1</h3>
							</br>
				<a href="show-playerone-page" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">Экран игрока 1</a>
						</div>
		</div>
		<div class="welcome-panel-column">
			<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
				<rect width="48" height="48" rx="4" fill="#000000"></rect>
			</svg>
			<div class="welcome-panel-column-content">
							<h3>Игрок 2</h3>
							</br>
				<a href="/show-playersecond-page" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">Экран игрока 2</a>
						</div>
		</div>
	</div>
	</div>
		</div>
    
    
    
    
    ';

    echo '</div>';
}
