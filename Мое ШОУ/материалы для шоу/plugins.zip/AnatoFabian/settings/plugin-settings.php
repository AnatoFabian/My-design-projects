<?php
function my_settings_page_content() {
    echo '<div class="wrap">';
    echo '<h2>Настройки</h2>';

    // Обработка сохранения настроек
    if (isset($_POST['save_settings'])) {
        // Проверка nonce для безопасности
        check_admin_referer('app-settings-nonce');

        // Проверяем, какие опции были выбраны и выполняем соответствующие действия
        if (isset($_POST['remove_admin_menu'])) {
            remove_admin_menu_items();
        }

        // Проверяем, было ли выбрано отключение верхней панели
        if (isset($_POST['remove_admin_bar'])) {
            show_admin_bar(false);
        } else {
            show_admin_bar(true); // Если не выбрано, то включаем верхнюю панель
        }

        // Другие опции и действия могут быть добавлены здесь

        // Сохраняем опции
        update_option('app_settings', $_POST);
    }

    // Получаем текущие настройки
    $app_settings = get_option('app_settings', array());

    // Отображаем форму настроек
    ?>
    <div class="wrap">
        <h2>Отключение боковых меню</h2>
        <form method="post">
            <?php wp_nonce_field('app-settings-nonce'); ?>
            <table class="form-table">
            <tr>
                    <th scope="row">Консоль</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_menu_page" value="1" <?php checked(isset($app_settings['remove_menu_page']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Консоль" 
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/index.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">Перейти в Консоль</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Записи</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Записи"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/edit.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Записи</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Медиафайлы</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Медиафайлы"
                        </label>
                    </td>
                    <td>
                            <a href="/wp-admin/upload.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                                Перейти в Медиафайлы</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Страницы</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Страницы"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/edit.php?post_type=page" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Страницы</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Комментарии</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Комментарии"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/edit-comments.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Комментарии</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Внешний вид</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Внешний вид"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/themes.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Внешний вид</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Плагины</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Плагины"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/plugins.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Плагины</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Пользователи</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Пользователи"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/users.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Пользователи</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Инструменты</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Инструменты"
                        </label>
                    </td>
                    <td>
                        <a href="/wp-admin/tools.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Инструменты</a>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Настройки</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_menu" value="1" <?php checked(isset($app_settings['remove_admin_menu']) && $app_settings['remove_admin_menu'], true); ?>>
                            Отключить пункт "Настройки"
                        </label>
                    </td>
</hr>
                    <td>
                        <a href="/wp-admin/options-general.php" target="_blank" class="page-title-action aria-button-if-js" role="button" aria-expanded="false">
                            Перейти в Настройки</a>
                    </td>
                    </tr>
            </table>
            <p class="submit">
                <input type="submit" name="save_settings" class="button-primary" value="Сохранить изменения">
            </p>
        </form>
                <h2>Отключение верхнее меню</h2>
        <form method="post">
            <?php wp_nonce_field('app-settings-nonce'); ?>
            <table class="form-table">
            <tr>
                    <th scope="row">Верхняя панель</th>
                    <td>
                        <label>
                            <input type="checkbox" name="remove_admin_bar" value="1" <?php checked(isset($app_settings['remove_admin_bar']) && $app_settings['remove_admin_bar'], true); ?>>
                            Отключить верхнюю панель на всем сейте (в админ и пользовательском)
                        </label>
                    </td>
                    
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="save_settings" class="button-primary" value="Сохранить изменения">
            </p>
        </form>
    </div>
    <?php
}


// Функция для удаления админ-меню
function remove_admin_menu_items() {
    // Ваш код для удаления админ-меню
    remove_menu_page('index.php');
    remove_menu_page('edit.php');
    remove_menu_page('upload.php');
    remove_menu_page('edit.php?post_type=page');
    remove_menu_page('edit-comments.php');
    remove_menu_page('themes.php');
    remove_menu_page('plugins.php');
    remove_menu_page('users.php');
    remove_menu_page('tools.php');
    remove_menu_page('options-general.php');
    
}

add_action('admin_menu', 'remove_admin_menu_items');
