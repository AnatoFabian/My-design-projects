<?php
// Защита от прямого доступа к файлу
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function load_players_page() {
    // Код для отображения страницы "Загрузка участников шоу"

    // Если пользователь не имеет права на просмотр страницы, завершаем выполнение
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'У вас нет прав для просмотра этой страницы.' );
    }

    // Получаем доступ к объекту базы данных WordPress
    global $wpdb;

    // Определите имя таблицы
    $table_name = $wpdb->prefix . 'players';

    // Обработка удаления участника
    if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['player_id'] ) ) {
        $player_id = intval( $_GET['player_id'] ); // Получаем ID участника

        // Вызываем функцию для удаления участника
        delete_player( $player_id );
    }
    // Пагинация
    $players_per_page = 10;
    $current_page = isset( $_GET['page_num'] ) ? absint( $_GET['page_num'] ) : 1;
    $offset = ( $current_page - 1 ) * $players_per_page;

    // Запрос к базе данных для выборки данных из таблицы
    $query = "SELECT * FROM $table_name";
    $players = $wpdb->get_results( $query );

    // Выводим данные на страницу
    echo '<div class="wrap">';
    echo '<h2>Список всех участников</h2>';
    echo '</hr>';
    

    // Выводим данные на страницу
    echo '<div class="container mt-5">';

    if ( $players ) {
        foreach ( $players as $player ) {
            echo '<div class="card mb-2">';
            echo '<div class="row no-gutters">';
            echo '<div class="col-md-3">';
            echo '<img src="' . esc_url( $player->player_avatar ) . '" class="card-img rounded-circle" alt="Аватар" style="width: 200px;border-radius: 50%;height: 200px;background-size: cover;">';
            echo '</div>';
            echo '<div class="col-md-8">';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . esc_html( $player->player_name ) . '</h5>';
            echo '<p>ID: ' . esc_html( '202351' . $player->player_id ) . '</p>'; // Формат player_id

            echo '<p>Телефон: ' . ( ! empty( $player->player_phone ) ? esc_html( '+7 ' . $player->player_phone ) : 'N/A' ) . '</p>'; // Формат player_phone

            echo '<p>Город: ' . ( ! empty( $player->player_city ) ? esc_html( $player->player_city ) : 'N/A' ) . '</p>';
            echo '<p>Никнейм: ' . ( ! empty( $player->player_nickname ) ? esc_html( $player->player_nickname ) : 'N/A' ) . '</p>';
            echo '<div class="social-links">';
            echo '<p>FB: ' . ( ! empty( $player->player_fb ) ? '<a href="https://www.facebook.com/' . esc_attr( $player->player_fb ) . '"><i class="fab fa-facebook"></i> ' . esc_html( $player->player_fb ) . '</a>' : 'N/A' ) . '</p>'; // Формат player_fb
            echo '<p>Twitter: ' . ( ! empty( $player->player_twitter ) ? '<a href="https://twitter.com/' . esc_attr( $player->player_twitter ) . '"><i class="fab fa-twitter"></i> ' . esc_html( $player->player_twitter ) . '</a>' : 'N/A' ) . '</p>'; // Формат player_twitter
            echo '<p>Instagram: ' . ( ! empty( $player->player_instagram ) ? '<a href="https://www.instagram.com/' . esc_attr( $player->player_instagram ) . '"><i class="fab fa-instagram"></i> ' . esc_html( $player->player_instagram ) . '</a>' : 'N/A' ) . '</p>'; // Формат player_instagram
            echo '<p>Telegram: ' . ( ! empty( $player->player_telegram ) ? '<a href="https://t.me/' . esc_attr( $player->player_telegram ) . '"><i class="fab fa-telegram"></i> ' . esc_html( $player->player_telegram ) . '</a>' : 'N/A' ) . '</p>'; // Формат player_telegram
            echo '<p>TikTok: ' . ( ! empty( $player->player_tiktok ) ? '<a href="https://www.tiktok.com/@' . esc_attr( $player->player_tiktok ) . '"><i class="fab fa-tiktok"></i> ' . esc_html( $player->player_tiktok ) . '</a>' : 'N/A' ) . '</p>'; // Формат player_tiktok
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo 'Участников шоу пока нет.';
    }

    echo '</div>';
}

// Добавляем страницу "Загрузка участников шоу" в админ-меню
function add_load_players_page() {

}

add_action( 'admin_menu', 'add_load_players_page' );


// Обработка удаления участника
if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['player_id'] ) ) {
    $player_id = intval( $_GET['player_id'] ); // Получаем ID участника

    // Здесь нужно добавить код для удаления участника с указанным ID из базы данных

}
function delete_player( $player_id ) {
    global $wpdb;

    $table_name = $wpdb->prefix . 'players';

    // Удаляем участника из базы данных по его ID
    $result = $wpdb->delete( $table_name, array( 'player_id' => $player_id ) );

    if ( $result !== false ) {
        echo 'Участник успешно удален!';
    } else {
        echo 'Ошибка при удалении участника: ' . $wpdb->last_error;
    }
}
