<!-- add-participant-page.php: Файл с кодом для отображения страницы "Добавление участника". -->

<?php
function add_participant_page() {
    if (!current_user_can('manage_options')) {
        wp_die('У вас нет прав для просмотра этой страницы.');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'players';

    // Определите путь к новой папке для загрузки
    $upload_dir = wp_upload_dir();
    $new_upload_path = $upload_dir['basedir'] . '/images/show-avatar/';

    // Если папки не существует, создайте ее
    if (!file_exists($new_upload_path)) {
        mkdir($new_upload_path, 0755, true);
    }

    if (isset($_POST['submit'])) {
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $phone_number = sanitize_text_field($_POST['phone_number']);
        $city = sanitize_text_field($_POST['city']);
        $nickname = sanitize_text_field($_POST['nickname']);
        $fb = sanitize_text_field($_POST['fb']);
        $twitter = sanitize_text_field($_POST['twitter']);
        $instagram = sanitize_text_field($_POST['instagram']);
        $telegram = sanitize_text_field($_POST['telegram']);
        $tiktok = sanitize_text_field($_POST['tiktok']);

        // Загрузка аватара
        $avatar_url = '';
        if (!empty($_FILES['user_photo']['name'])) {
            $upload_overrides = array('test_form' => false, 'unique_filename_callback' => null);
            $uploaded_file = wp_handle_upload($_FILES['user_photo'], $upload_overrides);

            if ($uploaded_file && isset($uploaded_file['file'])) {
                $file_name = sanitize_file_name($player->player_id . '-' . $nickname);

                // Перемещаем файл в новую папку
                $new_file_path = $new_upload_path . $file_name;
                rename($uploaded_file['file'], $new_file_path);

                // Обновляем ссылку на аватар
                $avatar_url = trailingslashit($upload_dir['baseurl'] . '/images/show-avatar/') . $file_name;
            }
        }

        // Создаем массив данных для вставки в БД
        $data = array(
            'player_name' => $first_name . ' ' . $last_name,
            'player_phone' => $phone_number,
            'player_city' => $city,
            'player_nickname' => '@' . $nickname,
            'player_avatar' => $avatar_url,
            'player_fb' => $fb,
            'player_twitter' => $twitter,
            'player_instagram' => $instagram,
            'player_telegram' => $telegram,
            'player_tiktok' => $tiktok,
        );

        // Вставляем данные в таблицу
        $result = $wpdb->insert($table_name, $data);

        echo '<div class="wrap">';
        echo '<h2>Добавить игрока</h2>';

        if ($result === false) {
            echo 'Ошибка при выполнении запроса в базу данных: ' . $wpdb->last_error;
        } else {
            echo 'Игрок успешно добавлен!';
        }
        echo '</div>';
    }
    ?>

    <div class="wrap">
        <h2>Добавить игрока</h2>

        <form method="post" enctype="multipart/form-data">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="first_name">Имя:</label></th>
                    <td><input type="text" name="first_name" id="first_name" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="last_name">Фамилия:</label></th>
                    <td><input type="text" name="last_name" id="last_name" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="phone_number">Номер телефона:</label></th>
                    <td><input type="text" name="phone_number" id="phone_number" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="city">Город:</label></th>
                    <td><input type="text" name="city" id="city" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="nickname">Никнейм:</label></th>
                    <td><input type="text" name="nickname" id="nickname" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb">Ссылка на FaceBook:</label></th>
                    <td><input type="text" name="fb" id="fb" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="twitter">Ссылка на Twitter:</label></th>
                    <td><input type="text" name="twitter" id="twitter" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="instagram">Ссылка на Instagram:</label></th>
                    <td><input type="text" name="instagram" id="instagram" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="telegram">Ссылка на Telegram:</label></th>
                    <td><input type="text" name="telegram" id="telegram" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="tiktok">Ссылка на Tik-Tok:</label></th>
                    <td><input type="text" name="tiktok" id="tiktok" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="user_photo">Фотография:</label></th>
                    <td>
                        <input type="file" name="user_photo" id="user_photo">
                    </td>
                </tr>
            </table>
            <?php submit_button('Добавить игрока', 'primary', 'submit'); ?>
        </form>
    </div>
    <?php
}
