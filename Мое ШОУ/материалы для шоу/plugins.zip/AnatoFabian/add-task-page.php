<!-- Файл с кодом для отображения страницы "Добавление задания". -->

<?php
function add_task_page() {
    // Код для отображения страницы "Добавление задания"
    if (!current_user_can('manage_options')) {
        wp_die('У вас нет прав для просмотра этой страницы.');
    }

    global $wpdb;

    if (isset($_POST['submit'])) {
        $task_type = sanitize_text_field($_POST['task_type']);
        $task_name = sanitize_text_field($_POST['task_name']);
        $task_description = sanitize_textarea_field($_POST['task_description']);
        $task_difficulty = intval($_POST['task_difficulty']);
        $task_sender = sanitize_text_field($_POST['task_sender']);
        $task_social_network = sanitize_text_field($_POST['task_social_network']);


        // Создаем массив данных для вставки в БД
        // Добавляем поле 'task_social_network' в массив данных для вставки в БД
        $data = array(
            'task_type' => $task_type,
            'task_name' => $task_name,
            'task_description' => $task_description,
            'task_difficulty' => $task_difficulty,
            'task_sender' => $task_sender,
            'task_social_network' => $task_social_network,
            'created_at' => current_time('mysql'),
        );

        // Имя таблицы в БД, где будут храниться задания и наказания
        $table_name = $wpdb->prefix . 'items_show';

        // Вставляем данные в таблицу
        $wpdb->insert($table_name, $data);

        echo 'Задание или наказание успешно добавлено!';
    }
    ?>

    <div class="wrap">
        <h2>Добавить задание или наказание</h2>

        <form method="post">
            <table class="form-table">
                <tr>
                    <th scope="row">Выберите тип:</th>
                    <td>
                        <label>
                            <input type="radio" name="task_type" id="task_type" value="task" checked> Задание
                        </label>
                        <label>
                            <input type="radio" name="task_type" id="task_type" value="punishment"> Наказание
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="task_sender">Имя/Никнейм:</label></th>
                    <td><input type="text" name="task_sender" id="task_sender" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="task_social_network">Социальная сеть:</label></th>
                    <td>
                    <select name="task_social_network" id="task_social_network">
                        <option value="My show">Мое ШОУ</option>
                        <option value="Facebook">Facebook</option>
                        <option value="Instagram">Instagram</option>
                        <option value="Twitter">Twitter</option>
                        <option value="VKontakte">VKontakte</option>
                        <option value="Tik-Tok">Tik-Tok</option>
                        <option value="YouTube">YouTube</option>
                        <option value="Chat GPT">Chat GPT</option>
                    </select>

                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="task_name">Название:</label></th>
                    <td><input type="text" name="task_name" id="task_name" class="regular-text" required></td>
                </tr>
                <tr>
                    <th scope="row"><label for="task_description">Текст:</label></th>
                    <td><textarea name="task_description" id="task_description" rows="5" class="large-text" required></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="task_difficulty">Уровень сложности:</label></th>
                    <td>
                        <select name="task_difficulty" id="task_difficulty">
                            <option value="1">1 (легко)</option>
                            <option value="2">2 (среднее)</option>
                            <option value="3">3 (сложное)</option>
                            <option value="4">4 (финальное)</option>
                        </select>
                    </td>
                </tr>
                

            </table>
            <?php submit_button('Добавить задание или наказание', 'primary', 'submit'); ?>
        </form>
    </div>
    <?php
}
$task_social_network = sanitize_text_field($_POST['task_social_network']);

// Добавляем поле 'task_social_network' в массив данных для вставки в БД
$data = array(
    'task_type' => $task_type,
    'task_name' => $task_name,
    'task_description' => $task_description,
    'task_difficulty' => $task_difficulty,
    'task_sender' => $task_sender,
    'task_social_network' => $task_social_network,
    'created_at' => current_time('mysql'),
);

// Выполняем SQL-запрос
$wpdb->insert($table_name, $data);
